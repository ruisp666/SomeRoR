class RemoveDescriptionToTodoItem < ActiveRecord::Migration
  def change
  end
end
